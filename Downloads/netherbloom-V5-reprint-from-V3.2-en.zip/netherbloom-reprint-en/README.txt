Netherbloom V5: the least to print if you already own V3.2
=========================================================

This zip holds only the files V3.2 cannot replace: what you must print to play V5 (CMYK, bleed and crop marks, the
same specification as the full MANUAL.pdf). Everything else comes from your V3.2 copy or can lie on the table unprinted.

1. Print (this zip)
- Mini cards (41 x 63): Memory 72 (new size and effects; they go into the new Books), Mist 56, Fate Mist 60; the Memory back.
- Standard cards (63 x 88): Commission 40, ending 20 (new in V5); 3 Soul cards (the Child of the Last Flame, the Garland
  Girl, Open Crossing: their special rules changed); 3 Mantles (Spirit Warden and Mistbreaker changed, the Reaper is new);
  the Commission, Soul and Mantle backs. Files printed only in part already hold just those pages: soul-cards 3 pages,
  mantle-cards 3 pages, card-backs-standard 3 pages.
- Bank tiles 37 (V5 has 8 kinds and fog-side symbols; the 20 V3 tiles show their Reach on the fog side, and mixing them
  would give information away).
- 8 tokens: Scar 3, Fog 2, forgotten 1, Black Water 1 (V3 has 6; Gentle needs 7), Root trait 1 (25 mm).
- Boards: the 3 river boards, the Loom of the Fates, the Ledger (V3's spaces and tracks differ).
- The 5 Books of Remembrance (every route changed).
- The Rulebook and the Solo Rulebook.

2. Keep from V3.2
- The 12 Ghost cards and their back (same text as V5).
- Mantles: Rootweaver and Bloombringer (same effect and summoning cost as V5).
- Soul cards: the King on the Barge and the Bride Who Stayed Below (same special rule as V5).
- Tokens: Root/Bloom 24, Shade 8, Black Water 6, Echo, Oar, Soul/Ghost, Push Through 4, Hold Fast, Shield, Resignation.
  Use 3 of the 15 Knot tokens as the knot markers, 1 of the 12 Light tokens as the Light marker and 1 of the 3 Fracture
  tokens as the Fracture marker.
- The box (same size; every V5 board fits; the contents list on it is V3's).

3. Skip to save cost
- The Misty Landing and Supply boards: they only hold things; the cards and tokens can lie on the table.
- The Player Aid: the Rulebook and the web table have the same content.

4. No longer used from V3.2
- V3's Memory, Mist, Keepsake and ending cards, bank tiles, river board, Loom, Ledger, Books, Rulebook and Player Aid.

Art: Flower Field, Frost, Ember, Echo Rock (tiles) and the Reaper (Mantle) are the approved concept sketches for now.
