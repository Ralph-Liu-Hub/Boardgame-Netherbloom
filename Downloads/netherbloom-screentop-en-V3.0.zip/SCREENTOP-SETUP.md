# Netherbloom on Screentop: setup guide

This guide builds the whole game in the Screentop editor (https://screentop.gg/@ralphlauxie/Netherbloom/edit/main),
following Screentop's own concepts (Assets → Components → Variants → Objects). Everything is sized at **2 units per
millimetre**, so cards, boards and tokens keep their real proportions (a card is 126 × 176).

Where a step says **Bulk update**, select all the variants (or objects) named, click **Update** in the top menu,
replace the function with the one given here, check the JSON preview and click **Save**.

## 1. Assets (upload the images)

Upload each file from the `assets` folder in **Assets → New asset**, with exactly this name, Rows and Columns:

| Asset name | File | Rows | Columns | What is in it |
|---|---|---|---|---|
| Memory Cards | memory-cards.jpg | 8 | 10 | 72 Memory cards (1–72), card back (73) |
| Mist Cards | mist-cards.jpg | 7 | 7 | 42 Mist cards (1–42), back (43) |
| Ghost Cards | ghost-cards.jpg | 3 | 5 | 12 Ghost cards (1–12), back (13) |
| Bank Cards | bank-cards.jpg | 4 | 6 | 20 bank cards (1–20), fog backs for Reach I, II, III (21–23) |
| Soul and Mantle Cards | soul-mantle-cards.jpg | 3 | 4 | 5 Souls (1–5), Soul back (6), 4 Mantles (7–10), Mantle back (11) |
| Tokens | tokens.png | 4 | 4 | 16 token faces (transparent corners) |
| River Panel 1 | river-panel-1.jpg | 1 | 1 | Reach I |
| River Panel 2 | river-panel-2.jpg | 1 | 1 | Reach II |
| River Panel 3 | river-panel-3.jpg | 1 | 1 | Reach III |
| Loom | loom-of-the-fates.jpg | 1 | 1 | Loom of the Fates |
| Ledger | the-ledger.jpg | 1 | 1 | The Ledger |
| Book Child | book-child.jpg | 2 | 4 | 8 pages |
| Book Garland | book-garland.jpg | 2 | 4 | 8 pages |
| Book King | book-king.jpg | 2 | 4 | 8 pages |
| Book Bride | book-bride.jpg | 2 | 4 | 8 pages |
| Book Open | book-open.jpg | 2 | 4 | 8 pages |

## 2. Card components

For each card component: **Components → New → Blank Tile**, Shape **Rectangle**, Width **126**, Height **176**,
Corner **8**. Then in its **Variants** section, clone Variant 1 until there are as many variants as listed, select
them all and run the bulk update.

### 2a. Memory Card — 72 variants
One component for all Memory cards, so the deck can be shuffled together (Screentop only shuffles objects of one
component). Names start with the pack: **Core**, **Echo** (the Open Crossing) or the Soul's name.

```js
const NAMES = [
  "Core · C01 Deep Roots",
  "Core · C02 Deep Roots",
  "Core · C03 Deep Roots",
  "Core · C04 Stubborn Root",
  "Core · C05 Stubborn Root",
  "Core · C06 Hold Fast",
  "Core · C07 Hold Fast",
  "Core · C08 Overreach",
  "Core · C09 Overreach",
  "Core · C10 Vigil",
  "Core · C11 Hold the Line",
  "Core · C12 Hold the Line",
  "Core · C13 Old Oath",
  "Core · C14 Open Hand",
  "Core · C15 Open Hand",
  "Core · C16 Open Hand",
  "Core · C17 Full Bloom",
  "Core · C18 Full Bloom",
  "Core · C19 Mend",
  "Core · C20 Mend",
  "Core · C21 Let Go",
  "Core · C22 Guide",
  "Core · C23 Guide",
  "Core · C24 Rekindle",
  "Core · C25 Unremember",
  "Core · C26 Unremember",
  "Core · C27 Unremember",
  "Core · C28 Blank Fog",
  "Core · C29 Unmake",
  "Core · C30 Wash Away",
  "Core · C31 Low Tide",
  "Core · C32 Lethe's Gift",
  "Echo · E01 Echo",
  "Echo · E02 Echo",
  "Echo · E03 Echo",
  "Echo · E04 Echo",
  "Echo · E05 Echo",
  "Echo · E06 Echo",
  "Echo · E07 Echo",
  "Echo · E08 Echo",
  "The King on the Barge · K01 Last Army",
  "The King on the Barge · K02 The Line",
  "The King on the Barge · K03 Heavy Crown",
  "The King on the Barge · K04 The Lake's Gift (Key Memory)",
  "The King on the Barge · K05 Honest Love",
  "The King on the Barge · K06 Too Late",
  "The King on the Barge · K07 Unremember",
  "The King on the Barge · K08 Wash Away",
  "The Garland Girl · G-01 Pretended Stranger",
  "The Garland Girl · G-02 The Song",
  "The Garland Girl · G-03 Every Flower",
  "The Garland Girl · G-04 One Flower Kept (Key Memory)",
  "The Garland Girl · G-05 The Willow",
  "The Garland Girl · G-06 Names of Herbs",
  "The Garland Girl · G-07 Low Tide",
  "The Garland Girl · G-08 Unremember",
  "The Bride Who Stayed Below · B01 Without a Word",
  "The Bride Who Stayed Below · B02 The Narrow Stair",
  "The Bride Who Stayed Below · B03 Almost Saved",
  "The Bride Who Stayed Below · B04 His Face (Key Memory)",
  "The Bride Who Stayed Below · B05 Noon Meadow",
  "The Bride Who Stayed Below · B06 His Hand",
  "The Bride Who Stayed Below · B07 Unremember",
  "The Bride Who Stayed Below · B08 Unmake",
  "Child of the Last Flame · L01 Coldest Doorway",
  "Child of the Last Flame · L02 Hunger",
  "Child of the Last Flame · L03 One More Light",
  "Child of the Last Flame · L04 Held (Key Memory)",
  "Child of the Last Flame · L05 Frosted Window",
  "Child of the Last Flame · L06 Roast Apples",
  "Child of the Last Flame · L07 Unremember",
  "Child of the Last Flame · L08 Lethe's Gift",
];

export default function(variant, index) {
  return {
    name: NAMES[index - 1],
    frontAsset: "Memory Cards",
    frontAssetIndex: index,
    backAsset: "Memory Cards",
    backAssetIndex: 73,
  };
}
```

### 2b. Mist Card — 42 variants
One component, so harsh Mist cards can be shuffled into a Reach's deck.

```js
const NAMES = [
  "Reach I · Rising Water",
  "Reach I · Rising Water",
  "Reach I · Shade",
  "Reach I · Shade",
  "Reach I · Shade Drawn Near",
  "Reach I · Withering",
  "Reach I · Fog Returns",
  "Reach I · Cold Wind",
  "Reach I · The Mist Parts",
  "Reach I · The Mist Parts",
  "Reach I · Rising Water",
  "Reach I · Shade Drawn Near",
  "Reach II · Rising Water",
  "Reach II · Rising Water",
  "Reach II · Shade",
  "Reach II · Shade",
  "Reach II · Shade Drawn Near",
  "Reach II · Withering",
  "Reach II · Withering",
  "Reach II · Fog Returns",
  "Reach II · Cold Wind",
  "Reach II · Echo Severed",
  "Reach II · Rising Water",
  "Reach II · Shade Drawn Near",
  "Reach III · Rising Water",
  "Reach III · Rising Water",
  "Reach III · Undertow",
  "Reach III · Shade Drawn Near",
  "Reach III · Twin Shades",
  "Reach III · Withering",
  "Reach III · Great Withering",
  "Reach III · Cold Wind",
  "Reach III · Bitter Wind",
  "Reach III · Echo Severed",
  "Reach III · Rising Water",
  "Reach III · Shade Drawn Near",
  "Harsh · Flood Surge",
  "Harsh · Shade Host",
  "Harsh · Wither Storm",
  "Harsh · Deep Cold",
  "Harsh · Karma Surge",
  "Harsh · Dark Wind",
];

export default function(variant, index) {
  return {
    name: NAMES[index - 1],
    frontAsset: "Mist Cards",
    frontAssetIndex: index,
    backAsset: "Mist Cards",
    backAssetIndex: 43,
  };
}
```

### 2c. Ghost Card — 12 variants (solo)

```js
const NAMES = [
  "Ghost 1 · Obsession",
  "Ghost 2 · Obsession",
  "Ghost 3 · Obsession",
  "Ghost 4 · Obsession",
  "Ghost 5 · Obsession",
  "Ghost 6 · Acceptance",
  "Ghost 7 · Acceptance",
  "Ghost 8 · Acceptance",
  "Ghost 9 · Acceptance",
  "Ghost 10 · Oblivion",
  "Ghost 11 · Oblivion",
  "Ghost 12 · Oblivion",
];

export default function(variant, index) {
  return {
    name: NAMES[index - 1],
    frontAsset: "Ghost Cards",
    frontAssetIndex: index,
    backAsset: "Ghost Cards",
    backAssetIndex: 13,
  };
}
```

### 2d. Bank Card — 20 variants
Each card's back is its Reach's fog side.

```js
const NAMES = [
  "Reach I · Fertile",
  "Reach I · Fertile",
  "Reach I · Fertile",
  "Reach I · Stony",
  "Reach I · Memory Site",
  "Reach I · Memory Site",
  "Reach II · Fertile",
  "Reach II · Fertile",
  "Reach II · Fertile",
  "Reach II · Stony",
  "Reach II · Stony",
  "Reach II · Memory Site",
  "Reach II · Memory Site",
  "Reach II · Grave",
  "Reach III · Fertile",
  "Reach III · Fertile",
  "Reach III · Stony",
  "Reach III · Memory Site",
  "Reach III · Memory Site",
  "Reach III · Grave",
];
const BACKS = [21, 21, 21, 21, 21, 21, 22, 22, 22, 22, 22, 22, 22, 22, 23, 23, 23, 23, 23, 23];

export default function(variant, index) {
  return {
    name: NAMES[index - 1],
    frontAsset: "Bank Cards",
    frontAssetIndex: index,
    backAsset: "Bank Cards",
    backAssetIndex: BACKS[index - 1],
  };
}
```

### 2e. Soul Card — 5 variants

```js
const NAMES = [
  "Soul · Child of the Last Flame",
  "Soul · The Garland Girl",
  "Soul · The King on the Barge",
  "Soul · The Bride Who Stayed Below",
  "Soul · Open Crossing",
];

export default function(variant, index) {
  return {
    name: NAMES[index - 1],
    frontAsset: "Soul and Mantle Cards",
    frontAssetIndex: index,
    backAsset: "Soul and Mantle Cards",
    backAssetIndex: 6,
  };
}
```

### 2f. Mantle Card — 4 variants

```js
const NAMES = [
  "Mantle · The Root-Weaver",
  "Mantle · The Spirit Warden",
  "Mantle · The Bloom-Bringer",
  "Mantle · The Fog-Breaker",
];

export default function(variant, index) {
  return {
    name: NAMES[index - 1],
    frontAsset: "Soul and Mantle Cards",
    frontAssetIndex: index + 6,
    backAsset: "Soul and Mantle Cards",
    backAssetIndex: 11,
  };
}
```

## 3. Tokens

Two **Blank Tile** components with Shape **Circle**: one variant per physical token, so **Select All → Create**
in the Chest puts out the whole supply. Two-sided tokens (Root/Bloom, Push Through, Soul/Ghost) flip with **F**.

### 3a. Large Token — Diameter 50, 9 variants

```js
// [name, front image, back image] in the Tokens asset
const TOKENS = [
  ["Oar", 1, 1],
  ["Push Through 1", 2, 3],
  ["Push Through 2", 2, 3],
  ["Push Through 3", 2, 3],
  ["Push Through 4", 2, 3],
  ["Hold Fast", 4, 4],
  ["Shield", 5, 5],
  ["Resignation", 6, 6],
  ["Soul / Ghost", 7, 8],
];

export default function(variant, index) {
  const [name, front, back] = TOKENS[index - 1];
  return { name, frontAsset: "Tokens", frontAssetIndex: front, backAsset: "Tokens", backAssetIndex: back };
}
```

### 3b. Small Token — Diameter 36, 69 variants

```js
// [name, front image, back image] in the Tokens asset
const TOKENS = [
  ["Root / Bloom 1", 9, 10],
  ["Root / Bloom 2", 9, 10],
  ["Root / Bloom 3", 9, 10],
  ["Root / Bloom 4", 9, 10],
  ["Root / Bloom 5", 9, 10],
  ["Root / Bloom 6", 9, 10],
  ["Root / Bloom 7", 9, 10],
  ["Root / Bloom 8", 9, 10],
  ["Root / Bloom 9", 9, 10],
  ["Root / Bloom 10", 9, 10],
  ["Root / Bloom 11", 9, 10],
  ["Root / Bloom 12", 9, 10],
  ["Root / Bloom 13", 9, 10],
  ["Root / Bloom 14", 9, 10],
  ["Root / Bloom 15", 9, 10],
  ["Root / Bloom 16", 9, 10],
  ["Root / Bloom 17", 9, 10],
  ["Root / Bloom 18", 9, 10],
  ["Root / Bloom 19", 9, 10],
  ["Root / Bloom 20", 9, 10],
  ["Root / Bloom 21", 9, 10],
  ["Root / Bloom 22", 9, 10],
  ["Root / Bloom 23", 9, 10],
  ["Root / Bloom 24", 9, 10],
  ["Shade 1", 11, 11],
  ["Shade 2", 11, 11],
  ["Shade 3", 11, 11],
  ["Shade 4", 11, 11],
  ["Shade 5", 11, 11],
  ["Shade 6", 11, 11],
  ["Shade 7", 11, 11],
  ["Shade 8", 11, 11],
  ["Black Water 1", 12, 12],
  ["Black Water 2", 12, 12],
  ["Black Water 3", 12, 12],
  ["Black Water 4", 12, 12],
  ["Black Water 5", 12, 12],
  ["Black Water 6", 12, 12],
  ["Fracture 1", 13, 13],
  ["Fracture 2", 13, 13],
  ["Fracture 3", 13, 13],
  ["Light 1", 14, 14],
  ["Light 2", 14, 14],
  ["Light 3", 14, 14],
  ["Light 4", 14, 14],
  ["Light 5", 14, 14],
  ["Light 6", 14, 14],
  ["Light 7", 14, 14],
  ["Light 8", 14, 14],
  ["Light 9", 14, 14],
  ["Light 10", 14, 14],
  ["Light 11", 14, 14],
  ["Light 12", 14, 14],
  ["Knot 1", 15, 15],
  ["Knot 2", 15, 15],
  ["Knot 3", 15, 15],
  ["Knot 4", 15, 15],
  ["Knot 5", 15, 15],
  ["Knot 6", 15, 15],
  ["Knot 7", 15, 15],
  ["Knot 8", 15, 15],
  ["Knot 9", 15, 15],
  ["Knot 10", 15, 15],
  ["Knot 11", 15, 15],
  ["Knot 12", 15, 15],
  ["Knot 13", 15, 15],
  ["Knot 14", 15, 15],
  ["Knot 15", 15, 15],
  ["Echo", 16, 16],
];

export default function(variant, index) {
  const [name, front, back] = TOKENS[index - 1];
  return { name, frontAsset: "Tokens", frontAssetIndex: front, backAsset: "Tokens", backAssetIndex: back };
}
```

## 4. Boards

You make **three components** here: **River Panel** (with 3 variants, one per Reach), **Loom** and **Ledger**.
A board is just a big picture card that never needs flipping, so its front and back use the same image.
Do them one at a time.

### 4a. River Panel (3 variants)

1. Go to **Components** and click **New → Blank Tile**.
2. Set **Name**: `River Panel`.
3. Under **Shape** set **Kind**: Rectangle, **Width**: `840`, **Height**: `594`, **Corner**: `8`.
4. Open this component's **Variants** section. There is already one variant, **Variant 1**. Click it and set:
   - **Front Asset**: `River Panel 1`, **Front Asset Index**: `1`
   - **Back Asset**: `River Panel 1`, **Back Asset Index**: `1`
   - (optional) **Name**: `Reach I`
5. Open Variant 1's item menu (the ⋯ beside it) and choose **Clone...** twice, so you have **3 variants**.
6. Click **Variant 2** and change both assets to `River Panel 2` (indexes stay `1`); optional name `Reach II`.
7. Click **Variant 3** and change both assets to `River Panel 3` (indexes stay `1`); optional name `Reach III`.

### 4b. Loom (1 variant)

1. **Components → New → Blank Tile**, **Name**: `Loom`.
2. **Shape**: Rectangle, **Width**: `594`, **Height**: `420`, **Corner**: `8`.
3. In **Variants**, click **Variant 1** and set Front Asset `Loom`, index `1`; Back Asset `Loom`, index `1`.

### 4c. Ledger (1 variant)

Same as the Loom, with **Name**: `Ledger` and both assets set to `Ledger`, index `1`.

### Check

Open the **Chest** in the main view, pick **River Panel**, **Select All**, **Create**: three river panels appear.
Do the same for Loom and Ledger. You will arrange and lock them in step 7, so it is fine if they overlap now.

## 5. Books of Remembrance — Book Page, 40 variants

**Blank Tile**, Rectangle, Width **420**, Height **594**, Corner **4**. Each Soul's Book is 8 pages; at the
table, put out the chosen Soul's pages 4–6 (the three Reach pages) and slide inscribed cards onto their wells.

```js
const BOOKS = ["Book Child", "Book Garland", "Book King", "Book Bride", "Book Open"];
const NAMES = [
  "Child of the Last Flame · page 1",
  "Child of the Last Flame · page 2",
  "Child of the Last Flame · page 3",
  "Child of the Last Flame · page 4",
  "Child of the Last Flame · page 5",
  "Child of the Last Flame · page 6",
  "Child of the Last Flame · page 7",
  "Child of the Last Flame · page 8",
  "The Garland Girl · page 1",
  "The Garland Girl · page 2",
  "The Garland Girl · page 3",
  "The Garland Girl · page 4",
  "The Garland Girl · page 5",
  "The Garland Girl · page 6",
  "The Garland Girl · page 7",
  "The Garland Girl · page 8",
  "The King on the Barge · page 1",
  "The King on the Barge · page 2",
  "The King on the Barge · page 3",
  "The King on the Barge · page 4",
  "The King on the Barge · page 5",
  "The King on the Barge · page 6",
  "The King on the Barge · page 7",
  "The King on the Barge · page 8",
  "The Bride Who Stayed Below · page 1",
  "The Bride Who Stayed Below · page 2",
  "The Bride Who Stayed Below · page 3",
  "The Bride Who Stayed Below · page 4",
  "The Bride Who Stayed Below · page 5",
  "The Bride Who Stayed Below · page 6",
  "The Bride Who Stayed Below · page 7",
  "The Bride Who Stayed Below · page 8",
  "The Open Crossing · page 1",
  "The Open Crossing · page 2",
  "The Open Crossing · page 3",
  "The Open Crossing · page 4",
  "The Open Crossing · page 5",
  "The Open Crossing · page 6",
  "The Open Crossing · page 7",
  "The Open Crossing · page 8",
];

export default function(variant, index) {
  const asset = BOOKS[Math.floor((index - 1) / 8)];
  const page = ((index - 1) % 8) + 1;
  return { name: NAMES[index - 1], frontAsset: asset, frontAssetIndex: page, backAsset: asset, backAssetIndex: page };
}
```

## 6. Hands (cards only their owner can see)

A Hand is a tray that hides its cards from everyone except the seat it belongs to. You make **one Hand component**,
then **4 Hand objects** (one per seat).

### 6a. Make the Hand component

1. Go to **Components** and click **New → Blank Container** (a Container, not a Tile).
2. Set **Name**: `Hand`.
3. Under **Shape** set **Kind**: Rectangle, **Width**: `640`, **Height**: `220`, **Radius**: `16`.

### 6b. Tell it which cards it holds

1. Open this component's **Dropzones** section and click **New → Anchor**.
2. In the new dropzone, set **Components**: `Memory Card` (so only Memory cards snap into a hand).
3. Open that dropzone's **Anchors** section and click **New → Line**. Leave its settings as they are: the cards
   will spread out evenly along the line.

### 6c. Make the 4 hands and give each one an owner

1. Open the Hand component's **Objects** section and click **New** to create an object on **Surface 1**.
   It is called **Hand #1**.
2. Click **Hand #1** and set:
   - **Seats**: `Seat 1`
   - **View Policy**: `Allow Seats` (only the seats listed above can see inside)
3. Repeat for **Hand #2** (Seats: `Seat 2`), **Hand #3** (`Seat 3`) and **Hand #4** (`Seat 4`).

### Check

In the main view, click **Join** and take **Seat 1**. Drag a Memory card into Hand #1: you can see it. Leave the
seat (or join as Seat 2): the card in Hand #1 is now hidden.

## 7. Lay out the table

Now put everything out once, in its starting place. Screentop saves where objects are, so every new game starts
from this layout.

1. In the main view, open the **Chest** (top right). For each component in turn (Memory Card, Mist Card,
   Ghost Card, Bank Card, Soul Card, Mantle Card, Large Token, Small Token, River Panel, Loom, Ledger), pick it,
   click **Select All**, then **Create**. (The Hands already exist from step 6. Leave the Book Pages for step 7c.)
2. Drag things into place. A simple layout that works:

```
                 [Mist I + Bank I]   [Mist II + Bank II]   [Mist III + Bank III]   [Harsh Mist]
 [Memory deck]   [ River Panel I  ]  [ River Panel II   ]  [ River Panel III   ]   [Token supply]
 [Soul cards]
 [Mantle cards]                      [  Loom  ]  [ Ledger ]
 [Ghost deck]
                 [ Hand 1 ]  [ Hand 2 ]  [ Hand 3 ]  [ Hand 4 ]
```

   - **River panels**: side by side, I on the left, III on the right, so the river runs 1 to 12.
   - **Mist cards**: sort them into piles by the start of their name (`Reach I`, `Reach II`, `Reach III`,
     `Harsh`). Hover a card, or hold **Space** to inspect it, to see its name.
   - **Bank cards**: sort into three piles by Reach the same way (fog side up: select and press **F** to flip).
   - **Tokens**: drag them into small piles by kind. Holding **right-click** while dragging stacks objects neatly.
3. Select each board (River Panel, Loom, Ledger) and press **L** to lock it, so cards slide over it without
   moving it.
4. Turn the card piles face down: select a pile (Control + A selects all of that component) and press **F**.

### 7c. The Books of Remembrance (Surface 2)

1. Press **2** to switch to Surface 2.
2. Open the **Chest**, pick **Book Page**, click **Select All**, then **Create**: the five Books (8 pages each)
   go on Surface 2, out of the way.
3. Press **1** to return to the table. When you play, bring over the chosen Soul's pages 4, 5 and 6
   (the three Reach pages): while dragging a page, press **1** to carry it to the table.

### Optional: place things with a script instead of dragging

If you prefer, select all objects of one component and use **Update** with a script like the ones below. They put
the objects at x, y (units from the middle of the table). They are optional: dragging by hand gives the same result.

```js
// River Panel: three panels side by side across the middle of the table
export default function(object, index) {
  return { x: (index - 2) * 840, y: 0 };
}
```

```js
// Mist Card: three Reach piles above the river, harsh cards in a fourth pile to the right
const REACH = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3, 3];

export default function(object, index) {
  const r = REACH[index - 1];
  return { x: r < 3 ? (r - 1) * 840 : 1380, y: -425 };
}
```

## 8. Before each game

Follow section 2 of the Rulebook. On Screentop:

1. **Memory deck**: keep the 32 Core cards plus the chosen Soul's 8 (or Core + Echo for the Open Crossing). Move
   the other packs away (to Surface 2: drag and press **2**). Select the deck, press **Z** to shuffle and **F** to
   turn it face down.
2. **Mist decks**: each Reach pile gets the Lantern's number of Harsh cards, picked at random; then shuffle each
   pile with **Z**.
3. **Bank cards**: shuffle each Reach's pile (**Z**) and deal them fog side up onto that Reach's banks.
4. **Black Water**: put only the Lantern's number into the Ledger's Black Water well; move the rest to Surface 2.
5. **Hands**: deal 3 cards into each player's Hand (4 in solo).

## 9. Play

Go back to the game's profile page and click **Play**. Screentop opens a room with a code (like #abcd); send the
link to the other players. Each player clicks **Join** and takes their own seat, so they see only their own Hand.
