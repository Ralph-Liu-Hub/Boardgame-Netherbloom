Netherbloom tokens, 18 mm: one CMYK JPG per side

Every JPG in this folder: 24 x 24 mm canvas, 567 x 567 px at 600 dpi, CMYK (Coated FOGRA39 profile embedded), JPEG quality 100, no chroma subsampling.
The token is centred on the canvas at true size. White around it is no ink.
Cut: a circle of 18 mm diameter, centred on the canvas. The art runs 2 mm past the cut (22 mm circle of art).
Front and back of one token share a name: <Token> Front <n>.jpg and <Token> Back <n>.jpg. Place both on the same spot,
centre on centre, back behind front, upright (head to head).

Token, copies:
  Root-Bloom: x24
  Shade: x8
  Black Water: x6
  Fracture: x3
  Light: x12
  Knot: x15
  Echo: x1
  Total: 69 tokens, 138 JPGs
