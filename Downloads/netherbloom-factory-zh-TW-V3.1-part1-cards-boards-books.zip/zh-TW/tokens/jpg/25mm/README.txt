Netherbloom tokens, 25 mm: one CMYK JPG per side

Every JPG in this folder: 31 x 31 mm canvas, 732 x 732 px at 600 dpi, CMYK (Coated FOGRA39 profile embedded), JPEG quality 100, no chroma subsampling.
The token is centred on the canvas at true size. White around it is no ink.
Cut: a circle of 25 mm diameter, centred on the canvas. The art runs 2 mm past the cut (29 mm circle of art).
Front and back of one token share a name: <Token> Front <n>.jpg and <Token> Back <n>.jpg. Place both on the same spot,
centre on centre, back behind front, upright (head to head).

Token, copies:
  Oar: x1
  Push Through: x4
  Hold Fast: x1
  Shield: x1
  Resignation: x1
  Soul: x1
  Total: 9 tokens, 18 JPGs
