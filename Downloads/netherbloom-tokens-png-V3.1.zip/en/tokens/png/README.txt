Netherbloom tokens, one PNG per side

Every PNG: 31 x 31 mm canvas, 732 x 732 px at 600 dpi, lossless (PNG), sRGB. Convert to CMYK with your press profile.
The token is centred on the canvas at true size. White around it is no ink.
Cut: a circle of 25 mm (large tokens) or 18 mm (small tokens) diameter, centred on the canvas. The art runs 2 mm past the cut.
Front and back of one token share a name: <Token> Front <n>.png and <Token> Back <n>.png. Place both on the same spot,
centre on centre, back behind front, upright (head to head).

Token, cut diameter, copies:
  Oar: 25 mm, x1
  Push Through: 25 mm, x4
  Hold Fast: 25 mm, x1
  Shield: 25 mm, x1
  Resignation: 25 mm, x1
  Soul: 25 mm, x1
  Root-Bloom: 18 mm, x24
  Shade: 18 mm, x8
  Black Water: 18 mm, x6
  Fracture: 18 mm, x3
  Light: 18 mm, x12
  Knot: 18 mm, x15
  Echo: 18 mm, x1
  Total: 78 tokens, 156 PNGs
